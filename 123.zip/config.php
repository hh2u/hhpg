<?php
require_once "vendor/autoload.php";
$tg_token = "1296653118:AAFtT-rTGLaDFzXELiNwPQsGkcIyJBybGiU";
$chat_id = "723121399";
?>